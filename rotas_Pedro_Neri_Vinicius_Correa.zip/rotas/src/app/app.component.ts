import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  // template: `
  //   <materialize-card>
  //     <materialize-button>Hello From Materialize Angular!</materialize-button>
  //   </materialize-card>
  // `
})
export class AppComponent {
  title = 'rotas';
}
