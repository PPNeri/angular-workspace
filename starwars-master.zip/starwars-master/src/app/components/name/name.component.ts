import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sw-name',
  templateUrl: './name.component.html',
  styleUrls: ['./name.component.scss']
})
export class NameComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
