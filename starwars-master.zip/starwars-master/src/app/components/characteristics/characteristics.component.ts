import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sw-characteristics',
  templateUrl: './characteristics.component.html',
  styleUrls: ['./characteristics.component.scss']
})
export class CharacteristicsComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
